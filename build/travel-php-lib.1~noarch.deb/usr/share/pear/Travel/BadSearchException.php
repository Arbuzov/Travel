<?php
/**
 * Исключение для Travel_Route выбрасывается 
 * в случае если один из поисковых параметров не задан
 * @author "arbuzov <info@whitediver.com>"
 * @package Travel пакет полезный при планировании
 * путешествий
 */
class Travel_BadSearchException extends Exception
{
    public function __construct($message, $code = 0, Exception $previous = null) {
        parent::__construct($message, $code, $previous);
    }
    
    public function __toString() {
        return __CLASS__ . "(unacceptable search params): [{$this->code}]: {$this->message}\n";
    }
}